import React from "react";

const DataCaptureHeader: React.FC = () => {
  return (
    <div className="flex justify-between items-center p-4 border-b border-gray-300">
      <h1 className="text-lg font-bold">New Due Diligence</h1>
      <div className="text-sm">
        <span className="mr-2">Algonomy</span> |
        <span className="ml-2 mr-2">Due Diligence ID: <strong>54647G</strong></span> |
        <span className="ml-2">Non Govt</span>
      </div>
    </div>
  );
};

export default DataCaptureHeader;
