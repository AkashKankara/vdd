"use client";

import React from "react";
import { useRouter } from "next/navigation";
import { FaInfoCircle, FaBug, FaShieldAlt, FaClipboardCheck, FaUserCheck } from "react-icons/fa";

interface Step {
  name: string;
  icon: React.ReactElement;
  route: string;
}

const steps: Step[] = [
  { name: "Initiate", icon: <FaInfoCircle size={14} />, route: "/new-due-diligence" },
  { name: "Data Capture", icon: <FaBug size={14} />, route: "/data-capture" },
  { name: "Assess", icon: <FaShieldAlt size={14} />, route: "/assess" },
  { name: "Review", icon: <FaClipboardCheck size={14} />, route: "/review" },
  { name: "Finalize", icon: <FaUserCheck size={14} />, route: "/finalize" },
];

interface StatusBarProps {
  activeStep?: string;
}

const StatusBar: React.FC<StatusBarProps> = ({ activeStep = "Initiate" }) => {
  const router = useRouter();

  return (
    <div className="flex justify-center items-center py-2 space-x-2">
      {steps.map((step, index) => {
        const currentIndex = steps.findIndex((s) => s.name === activeStep);
        const isActive = index === currentIndex;
        const isCompleted = index < currentIndex;

        return (
          <div key={index} className="flex items-center">
            {/* Step */}
            <div className="flex flex-col items-center">
              {/* Icon above button */}
              <div className={`p-1 rounded-full ${isActive ? "text-blue-600" : "text-gray-400"}`}>
                {step.icon}
              </div>

              {/* Step Button */}
              <button
                className={`relative flex items-center px-5 py-1.5 text-sm font-medium rounded-full transition-all
                  ${isActive ? "bg-blue-600 text-white shadow-md"
                    : isCompleted ? "border border-green-600 text-green-600 bg-white"
                    : "border border-gray-300 text-gray-700 bg-white"}`}
                onClick={() => router.push(step.route)}
              >
                {isCompleted && <span className="text-green-600 mr-1">✔</span>}
                {step.name}
              </button>
            </div>

            {/* Adjusted Dotted Line - Shifted Slightly Lower */}
            {index < steps.length - 1 && (
              <div className="flex items-center justify-center w-16 relative">
                <span className="border-dotted border-gray-400 border-t-2 w-full absolute top-2"></span>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
};

export default StatusBar;
